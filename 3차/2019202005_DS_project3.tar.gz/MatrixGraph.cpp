#include "MatrixGraph.h"
#include <iostream>
#include <vector>
#include <string>

MatrixGraph::MatrixGraph(bool type, int size) : Graph(type, size)
{
    // Allocate memory for the adjacency matrix
    m_Mat = new int* [size];
    for (int i = 0; i < size; i++)
    {
        m_Mat[i] = new int[size];
        memset(m_Mat[i], 0, sizeof(int) * size);
    }
}

MatrixGraph::~MatrixGraph()
{
    // Deallocate memory for the adjacency matrix
    for (int i = 0; i < getSize(); i++)
    {
        delete[] m_Mat[i];
    }
    delete m_Mat;
}

void MatrixGraph::getAdjacentEdges(int vertex, map<int, int>* m)
{
    int i = 0;

    // Traverse the row of the matrix to find adjacent edges
    while (i < getSize()) {
        if (m_Mat[vertex][i] != 0) {
            m->insert(pair<int, int>(i, m_Mat[vertex][i])); // Insert adjacent edge into the map
        }

        i++;
    }
}

void MatrixGraph::getAdjacentEdgesDirect(int vertex, map<int, int>* m)
{
    // Traverse the row of the matrix to find adjacent edges in a directed graph
    for (int i = 1; i <= getSize(); i++)
    {
        if (m_Mat[vertex - 1][i - 1] != 0)
        {
            m->insert(make_pair(i, m_Mat[vertex - 1][i - 1])); // Insert adjacent edge into the map
        }
    }
}

void MatrixGraph::insertEdge(int from, int to, int weight)
{
    // Insert an edge with the specified weight into the adjacency matrix
    m_Mat[from][to] = weight;
}

bool MatrixGraph::printGraph(ofstream& fout) {
    // If the file is not open, attempt to open it
    if (!fout.is_open()) {
        fout.open("log.txt", ios::app);
        if (!fout.is_open()) {
            return false;
        }
    }

    // If the graph size is invalid, return false
    if (getSize() < 0)
        return false;

    fout << "========PRINT========" << endl;

    fout << '\t';

    // Print column headers
    for (int i = 1; i <= getSize(); i++) {
        fout << "[" << i << "]" << '\t';
    }

    fout << endl;

    // Print the adjacency matrix
    for (int i = 0; i < getSize(); i++) {
        fout << "[" << i + 1 << "]";

        for (int j = 0; j < getSize(); j++) {
            fout << '\t' << m_Mat[i][j];
        }
        fout << endl;
    }

    fout << "=====================" << endl << endl;

    return true;
}
