#include "Manager.h"
#include <iomanip>

int main()
{
	Manager ds;	//Declare DS
	ds.run("command.txt");	//Run Program
	return 0;	//Return Program
}