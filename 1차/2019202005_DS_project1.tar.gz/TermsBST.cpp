#include "TermsBST.h"
#include <sstream>
#include <iomanip>
#include <fstream>


TermsBST::TermsBST() : root(nullptr)
{
    bstMap['A'] = nullptr;
    bstMap['B'] = nullptr;
    bstMap['C'] = nullptr;
    bstMap['D'] = nullptr;
}
TermsBST::~TermsBST()
{

}


TermsBSTNode* TermsBST::getRoot()
{
    return root;
}

// insert
void TermsBST::insertNode(MemberQueueNode newNode) {
    char bstType = newNode.getType();

    if (bstMap.find(bstType) == bstMap.end()) {
        return;
    }

    if (bstMap[bstType] == nullptr) {
        bstMap[bstType] = new TermsBSTNode(newNode);
    }
    else {
        insertRecursive(bstMap[bstType], newNode); //insert recursively
    }
    Expiration_Date(bstMap[bstType], newNode); //calculate expiration date
}

void TermsBST::insertRecursive(TermsBSTNode* currentNode, MemberQueueNode newNode) //insert recursively
{
    if (newNode.getDate() < currentNode->getBST_first_date()) //compare with date
    {
        if (currentNode->getLeft() == nullptr)
        {
            currentNode->setLeft(new TermsBSTNode(newNode));
        }
        else
        {
            insertRecursive(currentNode->getLeft(), newNode);
        }
    }
    else
    {
        if (currentNode->getRight() == nullptr)
        {
            currentNode->setRight(new TermsBSTNode(newNode));
        }
        else
        {
            insertRecursive(currentNode->getRight(), newNode);
        }
    }
}

// print
void TermsBST::printInOrder(TermsBSTNode* currentNode, ofstream& flog) //print by inorder
{
    if (currentNode != nullptr) {
        if (currentNode->getLeft() != nullptr) {
            printInOrder(currentNode->getLeft(), flog);
        }


        flog << currentNode->getBST_name() << "/" << currentNode->getBST_age() << "/" << currentNode->getBST_first_date() << "/" << currentNode->getBST_last_date() << endl;
        cout << currentNode->getBST_name() << "/" << currentNode->getBST_age() << "/" << currentNode->getBST_first_date() << "/" << currentNode->getBST_last_date() << endl;
       

      
        if (currentNode->getRight() != nullptr) {
            printInOrder(currentNode->getRight(), flog);
        }
    }
}


void TermsBST::print(string bstType, ofstream& flog) {
    char bstCharType = bstType[0];
    if (bstMap.find(bstCharType) == bstMap.end() || bstMap[bstCharType] == nullptr) // Check if the BST with the specified type exists or is null
    {
        flog << "===== ERROR =====" << endl;
        flog << 500 << endl;
        flog << "=================" << endl << endl;

        cout << "===== ERROR =====" << endl;
        cout << 500 << endl;
        cout << "=================" << endl << endl;
        return;
    }
    else
    {
        flog << "===== PRINT =====" << endl;
        flog << "TermsBST " << bstCharType << endl;

        cout << "===== PRINT =====" << endl;
        cout << "TermsBST " << bstCharType << endl;
    }
    printInOrder(bstMap[bstCharType], flog); //print by inorder

    flog << "==============" << endl << endl;
    cout << "==============" << endl << endl;
}

string TermsBST::searchNode(TermsBSTNode* currentNode, string name) //search node by name
{
    if (currentNode == nullptr) {
        return ""; 
    }

    if (currentNode->getBST_name() == name)
    {
        return currentNode->getBST_first_date(); //get date info
    }

    string leftResult = searchNode(currentNode->getLeft(), name); //get date info

    string rightResult = searchNode(currentNode->getRight(), name); //get date info

    if (leftResult != "") {
        return leftResult;
    }
    else {
        return rightResult;
    }
}

// delete
void TermsBST::deleteNode(string name) {
    char bstType = ' '; 
    for (const auto& pair : bstMap) {
        char type = pair.first;  // Get the type
    TermsBSTNode* rootNode = pair.second;  // Get the root node
        string date = searchNode(rootNode, name); //Get date info
        if (!date.empty()) {
            bstType = type;
            bstMap[bstType] = deleteRecursive(bstMap[bstType], date);// Delete the node with the found date 
            break;
        }
    }
    if (bstType == ' ') {
        return;
    }
}
 
TermsBSTNode* TermsBST::deleteRecursive(TermsBSTNode* currentNode, string date) { //delete node recursively
    if (currentNode == nullptr) {
        return currentNode;
    }

    // Compare with date and delete recursively
    if (date < currentNode->getBST_first_date()) {

        currentNode->setLeft(deleteRecursive(currentNode->getLeft(), date));
    }
    else if (date > currentNode->getBST_first_date()) {
        currentNode->setRight(deleteRecursive(currentNode->getRight(), date));
    }
    else {// If the left child is null
        if (currentNode->getLeft() == nullptr) {

            TermsBSTNode* temp = currentNode->getRight();
            delete currentNode;
            return temp;
        }

        // If the right child is null
        else if (currentNode->getRight() == nullptr) {
            TermsBSTNode* temp = currentNode->getLeft();
            delete currentNode;
            return temp;
        }
        // If both left and right children are present
        // Copy the data of the minimum node
        TermsBSTNode* temp = findMin(currentNode->getRight());
        currentNode->setBST_name(temp->getBST_name());
        currentNode->setBST_age(temp->getBST_age());
        currentNode->setBST_first_date(temp->getBST_first_date());
        currentNode->setBST_last_date(temp->getBST_last_date());

        // Recursively delete the minimum node
        currentNode->setRight(deleteRecursive(currentNode->getRight(), temp->getBST_name()));
    }

    return currentNode;
}

TermsBSTNode* TermsBST::findMin(TermsBSTNode* node) //find min node
{
    while (node->getLeft() != nullptr) {
        node = node->getLeft();
    }
    return node;
}

TermsBSTNode* deleteMin(TermsBSTNode* root) //delete min node
{
    if (root == nullptr) {
        return nullptr;
    }
    if (root->getLeft() == nullptr) {
        TermsBSTNode* temp = root->getRight();
        delete root;
        return temp;
    }
    root->setLeft(deleteMin(root->getLeft()));
    return root;
}

void TermsBST::deleteNodes_Date(string date) 
{
    //iterator each type and delete recursively
    for (char type : {'A', 'B', 'C', 'D'}) {
        if (bstMap.find(type) != bstMap.end()) {
            bstMap[type] = deleteNodes_Date_Recursive(bstMap[type], date);
        }
    }
}

TermsBSTNode* TermsBST::deleteNodes_Date_Recursive(TermsBSTNode* root, string date) //delete by date recursively
{
    if (root == nullptr) {
        return nullptr;
    }

    root->setLeft(deleteNodes_Date_Recursive(root->getLeft(), date));

    root->setRight(deleteNodes_Date_Recursive(root->getRight(), date));

    // compare with expiration date & delete
    if (root->getBST_last_date() < date) {
        if (root->getLeft() == nullptr) {
            TermsBSTNode* temp = root->getRight();
            delete root;
            return temp;
        }
        else if (root->getRight() == nullptr) {
            TermsBSTNode* temp = root->getLeft();
            delete root;
            return temp;
        }

        //when both left and right children are present
        TermsBSTNode* minRightSubtree = findMin(root->getRight()); 

        // Update the expiration date
        root->setBST_last_date(minRightSubtree->getBST_last_date());
        
        // Recursively delete the minimum node
        root->setRight(deleteMin(root->getRight()));
    }

    return root;
}


string TermsBST::ExpirationDate(TermsBSTNode* currentNode, MemberQueueNode newNode) // Calculate expiration dates for nodes in the NameBST
{
    if (currentNode != nullptr)
    {
        // extract the year, month, and day from the first date of the current node
        int year, month, day;
        char dash1, dash2;
        istringstream(currentNode->getBST_first_date()) >> year >> dash1 >> month >> dash2 >> day;

        if (newNode.getName() == currentNode->getBST_name())
        {
            if (currentNode->getBSTType() == 'A')
            {
                month += 6;

                if (month > 12) {
                    year += month / 12;
                    month %= 12;
                }
            }
            else if (currentNode->getBSTType() == 'B')
            {
                year++;
            }
            else if (currentNode->getBSTType() == 'C')
            {
                year += 2;
            }
            else if (currentNode->getBSTType() == 'D')
            {
                year += 3;
            }

            // create a tm structure to represent the calculated expiration date
            std::tm expirationTime = { 0 };
            expirationTime.tm_year = year - 1900; // adjust the year as tm_year is the number of years since 1900
            expirationTime.tm_mon = month - 1;    // adjust the month
            expirationTime.tm_mday = day;

            std::ostringstream formattedDate;
            formattedDate << std::put_time(&expirationTime, "%Y-%m-%d"); // "YYYY-MM-DD" format
            std::string newDate = formattedDate.str();

            // update the last date of the current node with the calculated expiration date
            currentNode->setBST_last_date(newDate);
            return newDate;
        }

        // recursively process
        string leftExpiration = ExpirationDate(currentNode->getLeft(), newNode);
        string rightExpiration = ExpirationDate(currentNode->getRight(), newNode);

        // return rxpiration date
        if (leftExpiration > rightExpiration) {
            return leftExpiration;
        }
        else {
            return rightExpiration;
        }
    }

    return "";
}
void TermsBST::Expiration_Date(TermsBSTNode* currentNode, MemberQueueNode newNode)// Calculate expiration dates for nodes in the NameBST
{
    if (currentNode != nullptr)
    {
        // extract the year, month, and day from the first date of the current node
        int year, month, day;
        char dash1, dash2;
        istringstream(currentNode->getBST_first_date()) >> year >> dash1 >> month >> dash2 >> day;

        if (newNode.getName() == currentNode->getBST_name())
        {
            if (currentNode->getBSTType() == 'A')
            {
                month += 6;

                if (month > 12) {
                    year += month / 12;
                    month %= 12;
                }
            }
            else if (currentNode->getBSTType() == 'B')
            {
                year++;
            }
            else if (currentNode->getBSTType() == 'C')
            {
                year += 2;
            }
            else if (currentNode->getBSTType() == 'D')
            {
                year += 3;
            }

            // create a tm structure to represent the calculated expiration date
            std::tm expirationTime = { 0 };
            expirationTime.tm_year = year - 1900; // adjust the year as tm_year is the number of years since 1900
            expirationTime.tm_mon = month - 1;    // adjust the month 
            expirationTime.tm_mday = day;

            std::ostringstream formattedDate;
            formattedDate << std::put_time(&expirationTime, "%Y-%m-%d"); // "YYYY-MM-DD" format
            std::string newDate = formattedDate.str();

            // update the last date of the current node with the calculated expiration date
            currentNode->setBST_last_date(newDate);
        }

        // recursively process
        ExpirationDate(currentNode->getLeft(), newNode);
        ExpirationDate(currentNode->getRight(), newNode);
    }
}