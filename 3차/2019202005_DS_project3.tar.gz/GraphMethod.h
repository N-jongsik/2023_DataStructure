#ifndef _GRAPHMETHOD_H_
#define _GRAPHMETHOD_H_

#include "ListGraph.h"
#include "MatrixGraph.h"

bool BFS(Graph* graph, char option, int vertex, ofstream& fout);
bool DFS(Graph* graph, char option, int vertex, ofstream& fout);
bool KWANGWOON(Graph* graph, int vertex, ofstream& fout);
bool Kruskal(Graph* graph, ofstream& fout);
bool Dijkstra(Graph* graph, char option, int vertex, ofstream& fout);
bool Bellmanford(Graph* graph, char option, int s_vertex, int e_vertex, ofstream& fout);
bool FLOYD(Graph* graph, char option, ofstream& fout);

bool findVertex(Graph* graph, int vertex); 
int op_find(int x, int parent[]); 
void op_union(int a, int b, int parent[]); 
void QuickSort(vector<pair<int, pair<int, int>>>* arr, int low, int high); 
void InsertionSort(vector<pair<int, pair<int, int>>>* arr, int low, int high);
void print(int start, int i, int vertex, vector<int>* from, ofstream& fout);

#endif