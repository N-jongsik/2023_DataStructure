#include "BpTree.h"
#include <cmath>

bool BpTree::Insert(LoanBookData* book) {
	if (root == NULL)
	{
		BpTreeDataNode* node = new BpTreeDataNode();// Create a new BpTreeDataNode object
		node->insertDataMap(book->getName(), book);//insert data
		root = node;
		return true;
	}
	else //when exist root node
	{
		if (searchDataNode(book->getName()) == NULL) //when data no exist in tree
		{
			BpTreeNode* data = root;
			map<string, LoanBookData*>::iterator iter1;
			map<string, LoanBookData*>::iterator iter2;

			while (data->getMostLeftChild() != NULL)
			{
				data = data->getMostLeftChild();// Traverse to the leftmost leaf node
			}


			while (data != NULL)
			{
				bool inserted = false;

				for (iter1 = data->getDataMap()->begin(); iter1 != data->getDataMap()->end(); iter1++)// Iterate through the data map of the current node
				{
					if (book->getName() > iter1->first)
					{
						if (data->getNext() != NULL)// Check the next node if it exists
						{
							iter2 = data->getNext()->getDataMap()->begin();
							if (book->getName() < iter2->first)
							{
								inserted = true;
								break;
							}
						}
						else
						{
							inserted = true;
							break;
						}
					}
					else if (book->getName() < iter1->first)
					{
						inserted = true;
						break;
					}
				}

				if (inserted)
				{
					data->insertDataMap(book->getName(), book);
					if (excessDataNode(data))// Check for excess data in the node and split if necessary
					{
						splitDataNode(data);
					}
					return true;
				}

				if (data->getNext() == NULL)
					break;

				data = data->getNext();
			}
			return false;
		}
		else //when data exsist in tree
		{
			BpTreeNode* searchData = searchDataNode(book->getName());
			map<string, LoanBookData*>::iterator iter =searchData->getDataMap()->begin();

			for (iter; iter != searchData->getDataMap()->end(); iter++)// Iterate through the data map of the search node to find the matching book by name
			{
				if (iter->first == book->getName())
				{
					iter->second->updateCount(); // loan_count++	
				}
			}
		}

	}
	return true;
}

bool BpTree::excessDataNode(BpTreeNode* pDataNode) {
	if (pDataNode->getDataMap()->size() > order - 1) return true;//order is equal to the number of elements 
	else return false;
}

bool BpTree::excessIndexNode(BpTreeNode* pIndexNode) {
	if (pIndexNode->getIndexMap()->size() > order - 1)return true;//order is equal to the number of elements 
	else return false;
}

void BpTree::splitDataNode(BpTreeNode* pDataNode)
{
	// Create a new data node and an optional new index node
    BpTreeDataNode* newData = new BpTreeDataNode;
    BpTreeIndexNode* newIndex = NULL; 
    vector<string> v;
    int split_location = ceil((order - 1) / 2.0) + 1;// Calculate the split location
    int compare = 1;
	map<string, LoanBookData*>::iterator iter; 

    for (iter = pDataNode->getDataMap()->begin(); iter != pDataNode->getDataMap()->end(); ++iter)// Iterate through the data map of pDataNode
    {
        if (compare == split_location)
        {
            if (pDataNode->getParent() != NULL) // Check if pDataNode has a parent
            {
                pDataNode->getParent()->insertIndexMap(iter->first, newData);// Insert the key and the new data node into the parent index node

                if (excessIndexNode(pDataNode->getParent()))// Check for excess index node and split if necessary
                {
                    splitIndexNode(pDataNode->getParent());
                }
            }
            else// If no parent exists, create a new index node and insert the key and new data node
            {
                newIndex = new BpTreeIndexNode;
                newIndex->insertIndexMap(iter->first, newData);
            }

            newData->insertDataMap(iter->first, iter->second);// Insert the key and data into the new data node
            v.push_back(iter->first);
        }
        else if (compare > split_location)
        {
            newData->insertDataMap(iter->first, iter->second);// Insert the key and data into the new data node
            v.push_back(iter->first);
        }
        compare++;
    }

    for (const auto& key : v)
    {
        pDataNode->deleteMap(key);// Delete keys from pDataNode
    }

    newData->setNext(pDataNode->getNext());// Update the pointers to connect pDataNode and newDataNode
    if (newData->getNext() != NULL)
    {
        newData->getNext()->setPrev(newData);
    }

    pDataNode->setNext(newData);
    newData->setPrev(pDataNode);

    if (newIndex != NULL && newData->getParent() == NULL)// Handle the case when creating a new index node
    {
        newIndex->setMostLeftChild(pDataNode);
        pDataNode->setParent(newIndex);
        newData->setParent(newIndex);
    }
    else if (newIndex == NULL)// If no new index node is created, update the parent pointers
    {
        newData->setParent(pDataNode->getParent());
        pDataNode->setParent(newData->getParent());
    }

	// Check if there is no excess index node and the parent's leftmost child has no previous node
    if (!excessIndexNode(pDataNode->getParent()) && pDataNode->getParent()->getMostLeftChild()->getPrev() == NULL)
    {
        root = pDataNode->getParent();
    }
}

void BpTree::splitIndexNode(BpTreeNode* pIndexNode)
{
	// Create a new index node to store the split entries
    BpTreeIndexNode* newIndex = new BpTreeIndexNode;
	map<string, BpTreeNode*>::iterator iter;
    BpTreeNode* curNode = pIndexNode->getParent();// Get the parent node of the current index node
    BpTreeIndexNode* IndexNode = NULL;
	vector<string> v;
    int split_location = ceil((order - 1) / 2.0) + 1;// Calculate the split location based on the order of the B+ tree
    int compare = 1;


    for (iter = pIndexNode->getIndexMap()->begin(); iter != pIndexNode->getIndexMap()->end(); iter++)// Iterate over the entries in the original index node
    {
        if (compare == split_location)// Check if the current entry is at the split position
        {
            v.push_back(iter->first);// Record the key 

            if (curNode != NULL)// If there is a parent node, insert the new entry into it
            {
                curNode->insertIndexMap(iter->first, newIndex);
                newIndex->setParent(pIndexNode->getParent());
                newIndex->setMostLeftChild(iter->second);
                newIndex->getMostLeftChild()->setParent(newIndex);
            }
            else// If no parent, create a new index node as the parent
            {
                IndexNode = new BpTreeIndexNode;
                IndexNode->insertIndexMap(iter->first, newIndex);
                curNode = IndexNode;
                IndexNode->setMostLeftChild(pIndexNode);
                pIndexNode->setParent(IndexNode);
                newIndex->setParent(IndexNode);
                iter->second->setParent(newIndex);
                newIndex->setMostLeftChild(iter->second);
            }
        }
        else if (compare > split_location)// If beyond the split position, insert into the new index node
        {
            newIndex->insertIndexMap(iter->first, iter->second);
            iter->second->setParent(newIndex);
            v.push_back(iter->first);
        }
        compare++;
    }

    for (int i = 0; i < v.size(); i++)
    {
        pIndexNode->deleteMap(v[i]);// Delete the entries that were moved to the new index node
    }

    if (IndexNode != NULL && IndexNode->getMostLeftChild() != NULL)// Handle root adjustment if the parent node becomes the new root
    {
        BpTreeNode* temp = IndexNode;
        while (temp->getMostLeftChild() != NULL)
        {
            temp = temp->getMostLeftChild();
        }

        if (temp->getPrev() == NULL)
        {
            root = IndexNode;
        }
    }

    if (excessIndexNode(curNode))// Recursively split the parent node if it exceeds its capacity
    {
        splitIndexNode(curNode);
    }
}


BpTreeNode* BpTree::searchDataNode(string name) {
	BpTreeNode* pCur = root;

	while (pCur->getMostLeftChild() != NULL) {
        pCur = pCur->getMostLeftChild();// Traverse to the leftmost leaf node
    }

	while (pCur != NULL) {// Search for the data node with name
        map<string, LoanBookData*>::iterator dataIter;// Iterate through the data map of the current node
        for (dataIter = pCur->getDataMap()->begin(); dataIter != pCur->getDataMap()->end(); dataIter++) {
            if (dataIter->first == name) {
                return pCur; 
            }
        }

        pCur = pCur->getNext();// Move to the next node in the linked list
    }

	return NULL;
}

bool BpTree::searchBook(string name, ofstream& flog) {
	BpTreeNode* node = root;
	
	while (node->getMostLeftChild() != NULL) {
		node = node->getMostLeftChild();
	}
	map<string, LoanBookData*>::iterator iter;
	while (node != NULL) {
		for (iter = node->getDataMap()->begin(); iter != node->getDataMap()->end(); iter++) {
			if (iter->second)
			{
				if (iter->second->getName() == name)
				{
					if (!(iter->second->getCode() <= 200 && iter->second->getLoanCount() >= 3) &&
						!(iter->second->getCode() >= 300 && iter->second->getCode() <= 400 && iter->second->getLoanCount() >= 4) &&
						!(iter->second->getCode() >= 500 && iter->second->getCode() <= 700 && iter->second->getLoanCount() >= 2))
					{
						if(iter->second->getCode() == 0)
						{
							string zero = "000";
							flog << "===========SEARCH_BP===========" << endl;
							flog << iter->second->getName() << "/" << zero << "/" << iter->second->getAuthor() << "/" << iter->second->getYear() << "/" << iter->second->getLoanCount() << endl;
							flog << "===============================" << endl << endl;

							cout << "===========SEARCH_BP===========" << endl;
							cout << iter->second->getName() << "/" << zero << "/" << iter->second->getAuthor() << "/" << iter->second->getYear() << "/" << iter->second->getLoanCount() << endl;
							cout << "===============================" << endl << endl ;
						}
						else{
							flog << "===========SEARCH_BP===========" << endl;
							flog << iter->second->getName() << "/" << iter->second->getCode() << "/" << iter->second->getAuthor() << "/" << iter->second->getYear() << "/" << iter->second->getLoanCount() << endl;
							flog << "===============================" << endl << endl;

							cout << "===========SEARCH_BP===========" << endl;
							cout << iter->second->getName() << "/" << iter->second->getCode() << "/" << iter->second->getAuthor() << "/" << iter->second->getYear() << "/" << iter->second->getLoanCount() << endl;
							cout << "===============================" << endl << endl ;
						}
						
						return true;
					}
				}
			}		
		}
		node = node->getNext();
	}
	return false;
}



bool BpTree::searchRange(string start, string end, ofstream& flog) {
	BpTreeNode* node = root;
	vector<LoanBookData*> v;
	map<string, LoanBookData*>::iterator iter;

	while (node->getMostLeftChild() != NULL) 
	{
    	node = node->getMostLeftChild();// Traverse to the leftmost leaf node
	}	
	
	while (node != NULL) {// Iterate through the linked list of data nodes
        for (iter = node->getDataMap()->begin(); iter != node->getDataMap()->end(); iter++) // Iterate through the data map of the current node
		{
            char firstChar = iter->first[0];
            if (firstChar >= start[0] && firstChar <= end[0]) // Check if the first character of the book name is within range
			{
                v.push_back(iter->second);
            }
        }
        node = node->getNext();// Move to the next node in the linked list
    }
	if (!v.empty()) {
		cout << "===========SEARCH_BP===========" << endl;
		flog << "===========SEARCH_BP===========" << endl;
		for (int i = 0; i < v.size(); i++) 
		{
			if (!(v[i]->getCode() <= 200 && v[i]->getLoanCount() >= 3) &&
				!(v[i]->getCode() >= 300 && v[i]->getCode() <= 400 && v[i]->getLoanCount() >= 4) &&
				!(v[i]->getCode() >= 500 && v[i]->getCode() <= 700 && v[i]->getLoanCount() >= 2))
				{
					if(v[i]->getCode() == 0)
					{
						string zero = "000";
						cout << v[i]->getName() << "/" << zero << "/" << v[i]->getAuthor() << "/" << v[i]->getYear() << "/" << v[i]->getLoanCount() << endl;
						flog << v[i]->getName() << "/" << zero << "/" << v[i]->getAuthor() << "/" << v[i]->getYear() << "/" << v[i]->getLoanCount() << endl;
					}
					else{
						cout << v[i]->getName() << "/" << v[i]->getCode() << "/" << v[i]->getAuthor() << "/" << v[i]->getYear() << "/" << v[i]->getLoanCount() << endl;
						flog << v[i]->getName() << "/" << v[i]->getCode() << "/" << v[i]->getAuthor() << "/" << v[i]->getYear() << "/" << v[i]->getLoanCount() << endl;
					}
					
				}
		}
			
		cout << "===============================" << endl << endl;
		flog << "===============================" << endl << endl;
		return true;
	}
	else {
		return false;
	}
}

void BpTree::Print(BpTreeNode* pCur, ofstream& flog) {
	if (pCur) {
		if (pCur->getIsLeaf()) {
			map<string, LoanBookData*> dataMap = *pCur->getDataMap();// Iterate through the data map of the leaf node
			for (auto iter = dataMap.begin(); iter != dataMap.end(); ++iter) {
				if (!(iter->second->getCode() <= 200 && iter->second->getLoanCount() >= 3) &&
					!(iter->second->getCode() >= 300 && iter->second->getCode() <= 400 && iter->second->getLoanCount() >= 4) &&
					!(iter->second->getCode() >= 500 && iter->second->getCode() <= 700 && iter->second->getLoanCount() >= 2))
				{
					if(iter->second->getCode() == 0)
					{
						string zero = "000";
						flog << iter->second->getName() << "/" << zero << "/"
						<< iter->second->getAuthor() << "/" << iter->second->getYear() << "/"
						<< iter->second->getLoanCount() << endl;
						cout << iter->second->getName() << "/" << zero << "/"
						<< iter->second->getAuthor() << "/" << iter->second->getYear() << "/"
						<< iter->second->getLoanCount() << endl;
					}
					else{
						flog << iter->second->getName() << "/" << iter->second->getCode() << "/"
						<< iter->second->getAuthor() << "/" << iter->second->getYear() << "/"
						<< iter->second->getLoanCount() << endl;
						cout << iter->second->getName() << "/" << iter->second->getCode() << "/"
						<< iter->second->getAuthor() << "/" << iter->second->getYear() << "/"
						<< iter->second->getLoanCount() << endl;
					}
					
				}
			}
		}
		else {
			
			Print(pCur->getMostLeftChild(), flog);// Recursively print the leftmost child
		}
		Print(pCur->getNext(), flog);// Continue printing the next node in the linked list
	}
}



bool BpTree::IsEmpty() {
	return (root == nullptr); 
}
