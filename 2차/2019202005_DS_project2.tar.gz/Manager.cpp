#include "Manager.h"
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

void Manager::run(const char* command)
{
    fin.open(command);
    flog.open("log.txt", ios::app);
    if (!fin)
    {
        flog << "File Open Error" << endl;
        return;
    }

    while (!fin.eof())
    {
        /* You must fill here */
        string line;
        getline(fin, line);
        stringstream ss(line);
        string command;
        ss >> command;

        if (command == "LOAD")//load loan_book.txt
            LOAD();//call LOAD function
        else if (command == "PRINT_BP")//print data in b+ tree
            PRINT_BP();//call PRINT_BP function
        else if (command == "SEARCH_BP")//search book in b+ tree
        {
            string argument1, argument2;
            ss >> argument1 >> argument2;

            if (!argument1.empty() && argument2.empty()) // input one argument
            {
                SEARCH_BP_BOOK(argument1);//call SEARCH_BP_BOOK function
            }
            else if (!argument1.empty() && !argument2.empty()) // input two argument
            {
                SEARCH_BP_RANGE(argument1, argument2);//call SEARCH_BP_RANGE function
            }
            else
                printErrorCode(300);

        }
        else if (command == "ADD") {//add data into b+ tree
            string name, code, author, year;
            ss >> name >> code >> author >> year;

            if (name.empty() || code.empty() || author.empty() || year.empty()) {
                printErrorCode(200);
            }
            else
                ADD(name,stoi(code),author,stoi(year));
        }
        else if (command == "PRINT_ST")//print data in selection tree with codenumber
        {
            string bookcode;
            ss >> bookcode;

            int codenumber = stoi(bookcode);

            if (codenumber >= 0 && codenumber <= 700)
            {
                PRINT_ST(stree,codenumber);//call PRINT_ST function
            }
            else
                printErrorCode(500);
        }

        else if (command == "DELETE")//delete root node in selection tree
        {
            DELETE();
        }

        else if (command == "EXIT")//exit program
        {
            flog << "=======EXIT========" << endl;
            flog << "Success " << endl; 
            flog << "===================" << endl << endl;
            cout << "=======EXIT========" << endl;
            cout << "Success " << endl;
            cout << "===================" << endl << endl;

            return; // Exit the program
        }
        else
            printErrorCode(700);
    }
    fin.close();
    return;
}

bool Manager::LOAD()
{
    ifstream file("loan_book.txt");//open loan_book file
    if (!file.is_open())
    {
        printErrorCode(100);
        return false;
    }

    // read data from loan_book.txt and insert data into bptree
    string line;
    while (getline(file, line))
    {
        istringstream iss(line);
        string name, code, author, year, loan_count;
        getline(iss, name, '\t');//get name
        getline(iss, code, '\t');//get code
        getline(iss, author, '\t');//get author
        getline(iss, year, '\t');//get year
        getline(iss, loan_count, '\t');//get loan_count

        int loanCount = stoi(loan_count);

        int codeValue = stoi(code);

        LoanBookData *book_data = new LoanBookData(name, codeValue, author, stoi(year), loanCount);// Create a new LoanBookData object

        if ((codeValue >= 000 && codeValue <= 200 && loanCount <= 3) ||
            (codeValue >= 300 && codeValue <= 400 && loanCount <= 4) ||
            (codeValue >= 500 && codeValue <= 700 && loanCount <= 2)) // Check conditions for insertion
        {
 
            bptree->Insert(book_data);//insert into b+ tree
        }
        else
        {
            stree->Insert(book_data);//insert into selection tree
        }
        
    }

    file.close();//close file
    cout << "==========LOAD=========" << endl;
    flog << "==========LOAD=========" << endl;
    printSuccessCode(); 
    return true;
}



bool Manager::ADD(string name, int code, string author, int year) {
    LoanBookData* bookData = new LoanBookData(name, code, author, year, 1);// Create a new LoanBookData object
    bool success;
    
    BpTreeNode* searchDataNode = bptree->searchDataNode(name);// Search for the data node in the B+ tree using the book name

    if (searchDataNode) 
    {
        map<string, LoanBookData*>::iterator iter = searchDataNode->getDataMap()->begin();// Iterate through the data map of the found node

        while (iter != searchDataNode->getDataMap()->end()) 
        {
            int codeValue = iter->second->getCode();
            int loanCount = iter->second->getLoanCount();

            if ((codeValue >= 0 && codeValue <= 200 && loanCount > 2) ||
                (codeValue >= 300 && codeValue <= 400 && loanCount > 3) ||
                (codeValue >= 500 && codeValue <= 700 && loanCount > 1)) // Check conditions for insertion
                {
                    stree->Insert(bookData);//insert into selection tree
                    success = false;
                    break; 
                }

            ++iter;//go to next data
        }

        if (iter == searchDataNode->getDataMap()->end()) {
            success = bptree->Insert(bookData);//insert into b+ tree
        }
    }
    else {
        success = bptree->Insert(bookData);//insert into b+ tree
    }

    if (success) {
        if(code == 0)
        {
            string zero = "000";
            flog << "========ADD========" << endl;
            flog << name << "/" << zero << "/" << author << "/" << year << endl;
            flog << "===================" << endl << endl;

            cout << "========ADD========" << endl;
            cout << name << "/" << zero << "/" << author << "/" << year << endl;
            cout << "===================" << endl << endl;
        }
        else{
            flog << "========ADD========" << endl;
            flog << name << "/" << code << "/" << author << "/" << year << endl;
            flog << "===================" << endl << endl;

            cout << "========ADD========" << endl;
            cout << name << "/" << code << "/" << author << "/" << year << endl;
            cout << "===================" << endl << endl;
        }
        
    }
    else {
        printErrorCode(200);
    }

    return success;
}


bool Manager::SEARCH_BP_BOOK(string book)//search data in b+ tree with book name
{
    bool success = bptree->searchBook(book, flog);//search book in b+ tree
    if (!success)
    {
        printErrorCode(300);
    }
    return success;
}

bool Manager::SEARCH_BP_RANGE(string s, string e)//search data in b+ tree with range
{
    bool success = bptree->searchRange(s,e, flog);//search book in b+ tree with range
    if (!success)
    {
        printErrorCode(300);
    }
    return success;
}

bool Manager::PRINT_BP()//print all data in b+ tree
{
    if (bptree->IsEmpty()) 
    {
        printErrorCode(400);
        return false;
    }


    flog << "========PRINT_BP========" << endl;
    cout << "========PRINT_BP========" << endl;

    bptree->Print(bptree->getRoot(), flog);//print all data in b+ tree

    flog << "========================" << endl << endl;
    cout << "========================" << endl << endl;

    return true;
}


bool Manager::PRINT_ST(SelectionTree* root, int codenumber)//print data in selection tree with code
{
    SelectionTreeNode* node = root->getRoot();

    if(codenumber == 000)//when code 000
    {
        node = node->getLeftChild();
        node = node->getLeftChild();
        node = node->getLeftChild();
    }
    else if(codenumber == 100)//when code 100
    {
        node = node->getLeftChild();
        node = node->getLeftChild();
        node = node->getRightChild();
    }
    else if(codenumber == 200)//when code 200
    {
        node = node->getLeftChild();
        node = node->getRightChild();
        node = node->getLeftChild();
    }
    else if(codenumber == 300)//when code 300
    {
        node = node->getLeftChild();
        node = node->getRightChild();
        node = node->getRightChild();
    }
    else if(codenumber == 400)//when code 400
    {
        node = node->getRightChild();
        node = node->getLeftChild();
        node = node->getLeftChild();
    }
    else if(codenumber == 500)//when code 500
    {
        node = node->getRightChild();
        node = node->getLeftChild();
        node = node->getRightChild();
    }
    else if(codenumber == 600)//when code 600
    {
        node = node->getRightChild();
        node = node->getRightChild();
        node = node->getLeftChild();
    }
    else if(codenumber == 700)//when code 700
    {
        node = node->getRightChild();
        node = node->getRightChild();
        node = node->getRightChild();
    }
    if(node == NULL)
    {
        printErrorCode(500);
        return false;
    }
        

    flog << "========PRINT_ST========" << endl;
    cout << "========PRINT_ST========" << endl;

    node->getHeap()->printSortedData(flog);//print data in selection tree with code

    flog << "========================" << endl << endl;
    cout << "========================" << endl << endl;

    return true;
}

bool Manager::DELETE()
{
    bool success = stree->Delete(flog);//delete root node in selection tree
    if (success)
    {
        cout << "========DELETE=========" << endl;
        flog << "========DELETE=========" << endl;
        printSuccessCode();
    }
        
    else
        printErrorCode(600);
    return true;
}

void Manager::printErrorCode(int n) {//ERROR CODE PRINT
    flog << "=========ERROR=========" << endl;
    flog << n << endl;
    flog << "=======================" << endl << endl;

    cout << "=========ERROR=========" << endl;
    cout << n << endl;
    cout << "=======================" << endl << endl;
}

void Manager::printSuccessCode() {//SUCCESS CODE PRINT 
    flog << "Success" << endl;
    flog << "=======================" << endl << endl;

    cout << "Success" << endl;
    cout << "=======================" << endl << endl;
}
