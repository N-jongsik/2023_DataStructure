#pragma once
#include "TermsListNode.h"
#include "MemberQueue.h"

class TermsLIST
{
private:
    TermsListNode* head;

public:
    //constructor
    TermsLIST();

    //destructor
    ~TermsLIST();

    TermsListNode* getHead();

    //insert
    void insertNode(MemberQueueNode newNode);

    void add_First_Node(MemberQueueNode Qnode);

    //search
    bool searchNode(MemberQueueNode newNode);

    //delete
    void deleteNode(string name);
    void deleteNode_date(string date);
};