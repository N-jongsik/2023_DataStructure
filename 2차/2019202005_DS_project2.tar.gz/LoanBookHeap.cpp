#include "LoanBookHeap.h"
#include <algorithm>
#include <functional>
#include <queue>
#include <fstream>

void LoanBookHeap::heapifyUp(LoanBookHeapNode* pN) {
    if (!pN) return;
    // Continue moving up the heap while the node has a parent and its book data name is less than its parent's book data name
    while (pN->getParent() && pN->getBookData()->getName() < pN->getParent()->getBookData()->getName()) {
        LoanBookData* temp = pN->getBookData();// Swap the book data of the current node with its parent
        pN->setBookData(pN->getParent()->getBookData());
        pN->getParent()->setBookData(temp);
        pN = pN->getParent();// Move to the parent node
    }
}



void LoanBookHeap::heapifyDown(LoanBookHeapNode* pN) {
    if (!pN) return; 

    while (true) {
        LoanBookHeapNode* smallest = pN;
        LoanBookHeapNode* left = pN->getLeftChild();
        LoanBookHeapNode* right = pN->getRightChild();

        // compare with left child
        if (left && left->getBookData()->getName() < smallest->getBookData()->getName()) {
            smallest = left;
        }

        // compare with right child
        if (right && right->getBookData()->getName() < smallest->getBookData()->getName()) {
            smallest = right;
        }

        if (smallest != pN) {
            LoanBookData* temp = pN->getBookData();
            pN->setBookData(smallest->getBookData());
            smallest->setBookData(temp);
            pN = smallest;
        }
        else {
            break; 
        }
    }
}

bool LoanBookHeap::Insert(LoanBookData* data) {
    LoanBookHeapNode* newNode = new LoanBookHeapNode();
    newNode->setBookData(data);

    // If the heap is empty, set the new node as the root
    if (root == NULL) {
        root = newNode;
        return true;
    }

    // Use a queue for level order traversal
    queue<LoanBookHeapNode*> levelOrderQueue;
    levelOrderQueue.push(root);

    while (!levelOrderQueue.empty()) {
        LoanBookHeapNode* current = levelOrderQueue.front();
        levelOrderQueue.pop();

        // Check if the left child is NULL, if yes, insert the new node there
        if (current->getLeftChild() == NULL) {
            current->setLeftChild(newNode);
            break;  // Node inserted, exit the loop
        }
        // Check if the right child is NULL, if yes, insert the new node there
        else if (current->getRightChild() == NULL) {
            current->setRightChild(newNode);
            break;  // Node inserted, exit the loop
        }

        // Both children are not NULL, add them to the queue for further exploration
        levelOrderQueue.push(current->getLeftChild());
        levelOrderQueue.push(current->getRightChild());
    }
    heapifyUp(newNode);

    return true;
}

void LoanBookHeap::printSortedData(ofstream& flog) {
    if (root == nullptr) {
        flog << "=========ERROR=========" << endl;
        flog << 500 << endl;
        flog << "=======================" << endl << endl;
        return;
    }

    // Create a priority queue to use heap properties
    priority_queue<LoanBookData*, vector<LoanBookData*>, function<bool(LoanBookData*, LoanBookData*)>> pq([](LoanBookData* a, LoanBookData* b) 
    {
        return a->getName() > b->getName(); // Min heap based on book names
    }
    );

    // Helper function to traverse the heap and push elements into the priority queue
    function<void(LoanBookHeapNode*)> traverseHeap = [&](LoanBookHeapNode* node) {
        if (node) {
            pq.push(node->getBookData());
            traverseHeap(node->getLeftChild());
            traverseHeap(node->getRightChild());
        }
    };

    // Traverse the heap and push elements into the priority queue
    traverseHeap(root);

    // Pop elements from the priority queue and print 
    while (!pq.empty()) {
        LoanBookData* data = pq.top();
        pq.pop();
        if(data->getCode() <= 200)
        {
            cout << data->getName() << "/" << data->getCode() << "/" << data->getAuthor() << "/" << data->getYear() << "/" << 3 << endl;
            flog << data->getName() << "/" << data->getCode() << "/" << data->getAuthor() << "/" << data->getYear() << "/" << 3 << endl;
        }
            
        else if(data->getCode() >= 300 && data->getCode() <= 400)
        {
            cout << data->getName() << "/" << data->getCode() << "/" << data->getAuthor() << "/" << data->getYear() << "/" << 4 << endl;
            flog << data->getName() << "/" << data->getCode() << "/" << data->getAuthor() << "/" << data->getYear() << "/" << 4 << endl;
        }
            
        else if(data->getCode() >= 500 && data->getCode() <= 700)
        {
            cout << data->getName() << "/" << data->getCode() << "/" << data->getAuthor() << "/" << data->getYear() << "/" << 2 << endl;
            flog << data->getName() << "/" << data->getCode() << "/" << data->getAuthor() << "/" << data->getYear() << "/" << 2 << endl;
        }
    }
}

void LoanBookHeap::traverseHeap(LoanBookHeapNode* node, ofstream& flog) {
    if (node) {
        // Recursively traverse the left and right subtrees
        traverseHeap(node->getLeftChild(), flog);
        traverseHeap(node->getRightChild(),flog);
    }
}

void LoanBookHeap::Delete(ofstream& flog) {
    if (root == nullptr) {
        flog << "=========ERROR=========" << endl;
        flog << 600 << endl;
        flog << "=======================" << endl << endl;

        cout << "=========ERROR=========" << endl;
        cout << 600 << endl;
        cout << "=======================" << endl << endl;
        return;
    }

    // Find the last node
    LoanBookHeapNode* lastNode = getLastNode(root);

    // Swap the data of the root and last nodes
    LoanBookData* temp = root->getBookData();
    root->setBookData(lastNode->getBookData());
    lastNode->setBookData(temp);

    // Remove the last node
    removeLastNode(root);

    // Heapify down from the root to maintain the heap property
    heapifyDown(root);
}

// Helper function to find the last node in the heap
LoanBookHeapNode* LoanBookHeap::getLastNode(LoanBookHeapNode* node) {
    if (node == nullptr)
        return nullptr;

    queue<LoanBookHeapNode*> q;
    q.push(node);
    LoanBookHeapNode* lastNode = nullptr;

    while (!q.empty()) {
        lastNode = q.front();
        q.pop();
        if (lastNode->getLeftChild())
            q.push(lastNode->getLeftChild());
        if (lastNode->getRightChild())
            q.push(lastNode->getRightChild());
    }

    return lastNode;
}

// Helper function to remove the last node in the heap
void LoanBookHeap::removeLastNode(LoanBookHeapNode* node) {
    if (node == nullptr)
        return;

    queue<LoanBookHeapNode*> q;
    q.push(node);
    LoanBookHeapNode* lastNode = nullptr;

    while (!q.empty()) {
        lastNode = q.front();
        q.pop();
        if (lastNode->getLeftChild()) {
            if (lastNode->getLeftChild()->getLeftChild() == nullptr && lastNode->getLeftChild()->getRightChild() == nullptr) {
                delete lastNode->getLeftChild();
                lastNode->setLeftChild(nullptr);
                break;
            }
            q.push(lastNode->getLeftChild());
        }
        if (lastNode->getRightChild()) {
            if (lastNode->getRightChild()->getLeftChild() == nullptr && lastNode->getRightChild()->getRightChild() == nullptr) {
                delete lastNode->getRightChild();
                lastNode->setRightChild(nullptr);
                break;
            }
            q.push(lastNode->getRightChild());
        }
    }
}


