#pragma once
#include "MemberQueue.h"
#include "TermsBST.h"

class TermsListNode
{
private:
    //TermsList data define
    TermsListNode* next;
    char pop_type;
    int count;
    TermsBST* bstPointer;
    string name;
    string list_date;

public:
    //constructor & destructor
    TermsListNode(MemberQueueNode newNode) : next(nullptr), pop_type(newNode.getType()), count(1), name(newNode.getName()), list_date(newNode.getDate()) {
        bstPointer = new TermsBST();
    }
    ~TermsListNode() {}

    //getter setter method
    TermsListNode* getNext() { return next; }

    void setNext(TermsListNode* next) { this->next = next; }

    char getData() {
        return pop_type;
    }
    string getDate(){
        return list_date;
    }
    string getName(){
        return name;
    }

    int getMemberCount();
    void incrementMemberCount();
    void decrementMemberCount();

    void setBSTPointer(TermsBST* bst) {
        bstPointer = bst;
    }

    TermsBST* getBSTPointer() {
        return bstPointer;
    }
};

