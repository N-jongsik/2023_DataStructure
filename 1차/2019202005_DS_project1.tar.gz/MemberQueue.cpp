#include "MemberQueue.h"
#include <iostream>
#include <stdexcept>

using namespace std;

MemberQueue::MemberQueue() //initialization
{
    capacity = 100;
    size = 0;
    frontIdx = 0;
    rearIdx = 0;
    data = new MemberQueueNode[capacity];
}

MemberQueue::~MemberQueue()
{
    delete[] data;
}

bool MemberQueue::empty() //when empty
{
    return size == 0;
}

bool MemberQueue::full() //when full
{
    return size == capacity;
}

void MemberQueue::push(const string& name, int age, const string& date, char type) //when add data into queue
{

    if (!full())
    {
        MemberQueueNode node{ name, age, date, type };
        data[rearIdx] = node;
        rearIdx = (rearIdx + 1) % capacity; //circular queue
        size++;
    }
}


MemberQueueNode MemberQueue::pop() //when pop from queue
{
    if (!empty())
    {
        MemberQueueNode temp = data[frontIdx];
        frontIdx = (frontIdx + 1) % capacity; //circular queue
        size--;
        return temp;
    }
}

MemberQueueNode MemberQueue::front()
{
    if (!empty())
    {
        return data[frontIdx];
    }
}

