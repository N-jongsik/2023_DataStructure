#include "SelectionTree.h"

bool SelectionTree::Insert(LoanBookData* newData) {
	SelectionTreeNode* node = root;
    // Navigate through the tree based on the code value
	if(newData->getCode() == 000)
    {
        node = node->getLeftChild();
        node = node->getLeftChild();
        node = node->getLeftChild();
    }
    else if(newData->getCode() == 100)
    {
        node = node->getLeftChild();
        node = node->getLeftChild();
        node = node->getRightChild();
    }
    else if(newData->getCode() == 200)
    {
        node = node->getLeftChild();
        node = node->getRightChild();
        node = node->getLeftChild();
    }
    else if(newData->getCode() == 300)
    {
        node = node->getLeftChild();
        node = node->getRightChild();
        node = node->getRightChild();
    }
    else if(newData->getCode() == 400)
    {
        node = node->getRightChild();
        node = node->getLeftChild();
        node = node->getLeftChild();
    }
    else if(newData->getCode() == 500)
    {
        node = node->getRightChild();
        node = node->getLeftChild();
        node = node->getRightChild();
    }
    else if(newData->getCode() == 600)
    {
        node = node->getRightChild();
        node = node->getRightChild();
        node = node->getLeftChild();
    }
    else if(newData->getCode() == 700)
    {
        node = node->getRightChild();
        node = node->getRightChild();
        node = node->getRightChild();
    }

    // Check if the heap is not initialized for the current node
	if (node->getHeap() == NULL) {
		LoanBookHeap* heap = new LoanBookHeap();
		heap->Insert(newData);
		node->setHeap(heap);
	}
	else {
		node->getHeap()->Insert(newData);// Insert the new data into the existing heap
	}

	if (node == NULL) {
		return false;
	}// Update the book data in the current node and its ancestors
	else {
		node->setBookData(newData);
		for (int i = 0; i < 3; i++) 
		{
			node = node->getParent();
			if(node->getBookData()->getName() > newData->getName() || node->getBookData()->getName().empty())
				node->setBookData(newData);
		}
		
		return true;
	}
}

bool SelectionTree::Delete(ofstream& flog) {
	SelectionTreeNode* node = root;
	SelectionTreeNode* node1 = NULL;
	SelectionTreeNode* node2 = NULL;
	SelectionTreeNode* node3 = NULL;

	LoanBookData* newData = root->getBookData();
    // Determine the navigation path based on the code value
	if(newData->getCode() == 000)
    {
        node1 = node->getLeftChild();
        node2 = node1->getLeftChild();
        node3 = node2->getLeftChild();
    }
    else if(newData->getCode() == 100)
    {
        node1 = node->getLeftChild();
        node2 = node1->getLeftChild();
        node3 = node2->getRightChild();
    }
    else if(newData->getCode() == 200)
    {
        node1 = node->getLeftChild();
        node2 = node1->getRightChild();
        node3 = node2->getLeftChild();
    }
    else if(newData->getCode() == 300)
    {
        node1 = node->getLeftChild();
        node2 = node1->getRightChild();
        node3 = node2->getRightChild();
    }
    else if(newData->getCode() == 400)
    {
        node1 = node->getRightChild();
        node2 = node1->getLeftChild();
        node3 = node2->getLeftChild();
    }
    else if(newData->getCode() == 500)
    {
        node1 = node->getRightChild();
        node2 = node1->getLeftChild();
        node3 = node2->getRightChild();
    }
    else if(newData->getCode() == 600)
    {
        node1 = node->getRightChild();
        node2 = node1->getRightChild();
        node3 = node2->getLeftChild();
    }
    else if(newData->getCode() == 700)
    {
        node1 = node->getRightChild();
        node2 = node1->getRightChild();
        node3 = node2->getRightChild();
    }

    // Create an array to store new empty book data objects
	LoanBookData* deleteNode[4];
	for (int i = 0; i < 4; i++) {
		deleteNode[i] = new LoanBookData();
	}
    // Set book data in nodes to the newly created empty objects
	node->setBookData(deleteNode[0]);
	node1->setBookData(deleteNode[1]);
	node2->setBookData(deleteNode[2]);
	node3->setBookData(deleteNode[3]);
	node3->getHeap()->Delete(flog);// Perform heap deletion on the third node

	if (node3->getHeap()->getRoot() != NULL)// If the root of the heap is not NULL, set the book data of the third node to the root's book data
		node3->setBookData(node3->getHeap()->getRoot()->getBookData());
	// Perform reordering on the nodes
	reorder(node2);
	reorder(node1);
	reorder(node);

	return true;
}

bool SelectionTree::printBookData(int bookCode, ofstream& flog) {
	SelectionTreeNode* node = root;
	LoanBookData* newData = root->getBookData();
    // Determine the navigation path based on the code value
	if(newData->getCode() == 000)
    {
        node = node->getLeftChild();
        node = node->getLeftChild();
        node = node->getLeftChild();
    }
    else if(newData->getCode() == 100)
    {
        node = node->getLeftChild();
        node = node->getLeftChild();
        node = node->getRightChild();
    }
    else if(newData->getCode() == 200)
    {
        node = node->getLeftChild();
        node = node->getRightChild();
        node = node->getLeftChild();
    }
    else if(newData->getCode() == 300)
    {
        node = node->getLeftChild();
        node = node->getRightChild();
        node = node->getRightChild();
    }
    else if(newData->getCode() == 400)
    {
        node = node->getRightChild();
        node = node->getLeftChild();
        node = node->getLeftChild();
    }
    else if(newData->getCode() == 500)
    {
        node = node->getRightChild();
        node = node->getLeftChild();
        node = node->getRightChild();
    }
    else if(newData->getCode() == 600)
    {
        node = node->getRightChild();
        node = node->getRightChild();
        node = node->getLeftChild();
    }
    else if(newData->getCode() == 700)
    {
        node = node->getRightChild();
        node = node->getRightChild();
        node = node->getRightChild();
    }

	node->getHeap()->printSortedData(flog); //print data in heap
	return true;
}

void SelectionTree::reorder(SelectionTreeNode* node) {
    // Check if the left child's book data name is empty or greater than the right child's book data name
	if (node->getLeftChild()->getBookData()->getName().empty() || node->getLeftChild()->getBookData()->getName() > node->getRightChild()->getBookData()->getName()) 
	{
		node->setBookData(node->getRightChild()->getBookData());// Set the book data of the node to the right child's book data
	}
    // Check if the right child's book data name is empty or less than the left child's book data name
	else if (node->getRightChild()->getBookData()->getName().empty() || node->getLeftChild()->getBookData()->getName() < node->getRightChild()->getBookData()->getName()) 
	{
		node->setBookData(node->getLeftChild()->getBookData());// Set the book data of the node to the left child's book data
	}
}