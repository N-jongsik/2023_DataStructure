#include "ListGraph.h"
#include <iostream>
#include <utility>
#include <fstream>

ListGraph::ListGraph(bool type, int size) : Graph(type, size)
{
	m_Type = type;
	m_List = new map<int, int>[size];
}

ListGraph::~ListGraph()
{
	delete [] m_List;
}

void ListGraph::getAdjacentEdges(int vertex, map<int, int>* m)// Get adjacent edges for the specified vertex
{
	map<int, int>* v_map = v[vertex]; 

	map<int, int>::iterator i; 
	for (i = v_map->begin(); i!= v_map->end(); i++) { 
		m->insert(pair<int, int>(i->first, i->second)); 
	}
}

void ListGraph::getAdjacentEdgesDirect(int vertex, map<int, int>* m)// Get adjacent edges for the specified vertex (directed graph version)
{
	map<int, int>* v_map = v[vertex]; 

	map<int, int>::iterator i; 
	for (i = v_map->begin(); i!= v_map->end(); i++) { 
		m->insert(pair<int, int>(i->first, i->second)); 
	}
}

void ListGraph::insertEdge(int from, int to, int weight)// Insert an edge into the graph
{
    vector<map<int, int>*>::iterator it = v.begin();

    // Insert a placeholder for the 'from' vertex if it doesn't exist
    if (to == 0 && weight == 0)
    {
        it = v.insert(it + from, nullptr);
    }
    else
    {
        // Check if this is the first insertion for the 'from' vertex
        if (check != from)
        {
            m_List[from].insert(pair<int, int>(to, weight));
            it = v.insert(it + from, m_List + from);
            check = from;
        }
        else
        {
            // Insert the edge into the existing 'from' vertex
            m_List[from].insert(pair<int, int>(to, weight));
        }
    }

    return;
}

bool ListGraph::printGraph(ofstream& fout)// Print the graph to the specified output stream
{
    fout << "========PRINT========" << endl;

    for (int i = 0; i < m_Size; i++)
    {
        fout << "[" << i + 1 << "]";

        for (auto print_iter = m_List[i].begin(); print_iter != m_List[i].end(); print_iter++)
        {
            fout << " -> (" << print_iter->first + 1 << ", " << print_iter->second << ")"; 
        }
        fout << endl;
    }
    fout << "=====================" << endl << endl;
    return true;
}
