#include "TermsList.h"
#include <iostream>
#include <string>
#include "MemberQueue.h"
using namespace std;

TermsLIST::TermsLIST() : head(nullptr)
{

}

TermsLIST::~TermsLIST()
{

}

TermsListNode* TermsLIST::getHead()
{
        return head;
}
void TermsLIST::add_First_Node(MemberQueueNode newNode) { //add first node
    TermsListNode* node = new TermsListNode(newNode);
    node->setNext(head);
    head = node;
}

void TermsLIST::insertNode(MemberQueueNode newNode) //insert node and increase member count
{
    if (searchNode(newNode))
    {
        TermsListNode* currentNode = head;
        while (currentNode->getNext() != nullptr)
        {
            if (currentNode->getData() == newNode.type) //compare type
            {
                currentNode->incrementMemberCount();
                currentNode->getBSTPointer()->insertNode(newNode);
            }
            currentNode = currentNode->getNext();
        }

        if (currentNode->getData() == newNode.getType()) {
            currentNode->incrementMemberCount();
        }
    }
    else {
        if (getHead() == NULL) { // when it is first node
            add_First_Node(newNode);
            getHead()->getBSTPointer()->insertNode(newNode);
        }
        else { // when it is first type
            TermsListNode* currentNode = getHead();
            while (currentNode->getNext() != NULL) {
                currentNode = currentNode->getNext();
            }
            TermsListNode* node = new TermsListNode(newNode);
            currentNode->setNext(node);
            node->getBSTPointer()->insertNode(newNode);
        }

    }
}

bool TermsLIST::searchNode(MemberQueueNode newNode)
{
    if (getHead() == NULL) { // when first node
        return false;
    }
    else
    {
        TermsListNode* currentNode = head;

        while (currentNode->getNext() != NULL) { // when there is same type
            if (currentNode->getData() == newNode.getType()) {
                return true;
            }
            currentNode = currentNode->getNext();
        }
        if (currentNode->getData() == newNode.getType()) // when same type is last node
            return true;
        else // when there is no same type
            return false;
    }
}

void TermsLIST::deleteNode(string name)
{
    TermsListNode* currentNode = head;
    TermsListNode* prevNode = nullptr;

    while (currentNode != nullptr)
    {
        if (currentNode->getName() == name)
        {
            // Decrease the member count
            currentNode->decrementMemberCount();

            // If the count is 0, delete the node
            if (currentNode->getMemberCount() == 0)
            {
                if (prevNode != nullptr)
                {
                    prevNode->setNext(currentNode->getNext());
                }
                else
                {
                    // If the first node is being deleted, update the head
                    head = currentNode->getNext();
                }
                delete currentNode;
            }

            return; // Node found and updated, exit the function
        }

        prevNode = currentNode;
        currentNode = currentNode->getNext();
    }
}

void TermsLIST::deleteNode_date(string date)
{
    TermsListNode* currentNode = head;
    TermsListNode* prevNode = nullptr;

    while (currentNode != nullptr)
    {
        if (currentNode->getDate() < date) //compare date
        {
            // Decrease the member count
            currentNode->decrementMemberCount();

            // If the count is 0, delete the node
            if (currentNode->getMemberCount() == 0)
            {
                if (prevNode != nullptr)
                {
                    prevNode->setNext(currentNode->getNext());
                }
                else
                {
                    // If the first node is being deleted, update the head
                    head = currentNode->getNext();
                }
                delete currentNode;
            }

            return; // Node found and updated, exit the function
        }

        prevNode = currentNode;
        currentNode = currentNode->getNext();
    }
}

int TermsListNode::getMemberCount() //get member count
{
    return count;
}

void TermsListNode::incrementMemberCount() //increase member count
{
    count++;
}

void TermsListNode::decrementMemberCount() // decrease member count
{
    if (count > 0)
    {
        count--;
    }
}