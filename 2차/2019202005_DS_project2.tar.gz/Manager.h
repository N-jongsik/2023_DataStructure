#pragma once
#include "SelectionTree.h"
#include "BpTree.h"

class Manager
{
private:
	char* cmd;
	BpTree* bptree;
	SelectionTree* stree;

public:
	ofstream* fout; // fout
	ifstream fin;
	ofstream flog;

	Manager(int bpOrder)	//constructor
	{
		/* You must fill here */
		bptree = new BpTree(fout, bpOrder);
		stree = new SelectionTree(fout);
		Initial(stree);
	}


	~Manager()//destructor
	{
		/* You must fill here */
		delete bptree;
		delete stree;
	}

	void Initial(SelectionTree* node) {
    // Create an array to hold 15 SelectionTreeNode pointers
    SelectionTreeNode* min_winner_tree[16];

    // Create SelectionTreeNode objects and store them in the array
    for (int i = 1; i < 16; i++) 
	{
        min_winner_tree[i] = new SelectionTreeNode();
    }

    // Connect the nodes to form a binary tree
    for (int i = 1; i <= 7; i++) 
	{
        min_winner_tree[i]->setLeftChild(min_winner_tree[i * 2]);
        min_winner_tree[i]->setRightChild(min_winner_tree[i * 2 + 1]);
    }

    for (int i = 2; i < 16; i++) 
	{
        min_winner_tree[i]->setParent(min_winner_tree[i / 2]);
    }

    // Set the root of the tree
    node->setRoot(min_winner_tree[1]);
}

	void run(const char* command);
	bool LOAD();

	bool ADD(string name, int code, string author, int year);

	bool SEARCH_BP_BOOK(string book);
	bool SEARCH_BP_RANGE(string start, string end);

	bool PRINT_BP();
	bool PRINT_ST(SelectionTree* root, int codenumber);

	bool DELETE();

	void printErrorCode(int n);
	void printSuccessCode();

};
