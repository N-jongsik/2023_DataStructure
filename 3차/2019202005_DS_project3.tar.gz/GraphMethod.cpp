#include <iostream>
#include <vector>
#include "GraphMethod.h"
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <list>
#include <utility>

# define INF 0x3f3f3f3f

using namespace std;

bool BFS(Graph* graph, char option, int vertex, ofstream &fout)
{
	// Check if the vertex exists in the graph
	if (findVertex(graph, vertex) == false)
		return false; // If not, return false

	// Initialize a boolean vector to track visited vertices
	vector<bool> visited(graph->getSize() + 1, false);

	// Initialize all vertices as not visited
	for (int i = 0; i < graph->getSize(); i++)
		visited[i] = false;
	
	// Mark the starting vertex as visited
	visited[vertex - 1] = true;

	// Create a queue for BFS
	queue<int> q;
	q.push(vertex - 1); // Enqueue the starting vertex

	// Output header for BFS
	fout << "======== BFS ========" << endl;

	// Output information based on graph type (Directed or Undirected)
	if (option == 'Y')
	{
		fout << "Directed Graph BFS result" << endl;
		fout << "startvertex: " << vertex << endl;
	}
	else if (option == 'N')
	{
		fout << "Undirected Graph BFS result" << endl;
		fout << "startvertex: " << vertex << endl;
	}

	// Handle the case where the graph has only one vertex
	if (graph->getSize() == 1)
	{
		fout << vertex << endl;
		return true;
	}
	else {
		fout << vertex; // Output the starting vertex
	}

	// Perform BFS
	while (!q.empty())
	{
		vertex = q.front(); // Get the front of the queue
		q.pop(); // Dequeue

		// Create a map to store adjacent vertices
		map<int, int>* m = new map<int, int>;

		// Get adjacent vertices for the current vertex
		graph->getAdjacentEdges(vertex, m);

		// Iterate through adjacent vertices
		map<int, int>::iterator i;
		for (i = m->begin(); i != m->end(); i++)
		{
			int w = i->first; // Get the next vertex

			// If the next vertex is not visited
			if (!visited[w])
			{
				visited[w] = true; // Mark it as visited

				// Count the number of visited vertices
				int k = 0;
				for (int j = 0; j < graph->getSize(); j++)
				{
					if (visited[j] == true)
						k++;
				}

				// If all vertices are visited, print and return
				if (k == graph->getSize())
				{
					fout << " -> " << w + 1 << endl;
					fout << "=====================" << endl << endl;

					delete m; // Delete the dynamically allocated map
					return true; // Return true
				}

				q.push(w); // Enqueue the next vertex
				fout << " -> " << w + 1; // Output the next vertex
			}
		}
		delete m; // Delete the dynamically allocated map
	}

	// Output final formatting
	fout << endl;
	fout << "=====================" << endl << endl;

	return true; // Return true
}

bool DFS(Graph* graph, char option, int vertex, ofstream& fout)
{
	// Check if the vertex is present in the graph
	if (findVertex(graph, vertex) == false)
		return false;

	// Initialize the visited array
	vector<bool> visited(graph->getSize() + 1, false);

	// Initialize all elements of visited array to false
	for (int i = 0; i < graph->getSize(); i++)
		visited[i] = false;

	// Mark the starting vertex as visited
	visited[vertex - 1] = true;

	// Initialize the stack for DFS traversal
	stack<int> s;
	s.push(vertex - 1);

	fout << "======== DFS ========" << endl;

	if (option == 'Y')
	{
		fout << "Directed Graph DFS result" << endl;
		fout << "startvertex: " << vertex << endl;
	}
	else if (option == 'N')
	{
		fout << "UnDirected Graph DFS result" << endl;
		fout << "startvertex: " << vertex << endl;
	}

	// If the graph has only one vertex, print it and return
	if (graph->getSize() == 1)
	{
		fout << vertex << endl;
		return true;
	}
	else
	{
		fout << vertex;
	}

	// DFS traversal using stack
	while (!s.empty())
	{
		int w = s.top();
		s.pop();

		map<int, int>* m = new map<int, int>;

		graph->getAdjacentEdges(w, m);

		map<int, int>::iterator i;
		for (i = m->begin(); i != m->end(); i++)
		{
			int n = i->first;

			if (!visited[n])
			{
				visited[n] = true;

				int k = 0;
				for (int j = 0; j < graph->getSize(); j++)
				{
					if (visited[j] == true)
						k++;
				}

				// If all vertices are visited, print the arrow and finish
				if (k == graph->getSize())
				{
					fout << " -> " << n + 1 << endl;
					fout << "=====================" << endl << endl;

					delete m;
					return true;
				}

				s.push(w);
				s.push(n);
				fout << " -> " << n + 1;
				break;
			}
		}
		delete m;
	}

	fout << endl;
	fout << "=====================" << endl << endl;

	return true;
}


bool Kruskal(Graph* graph, ofstream &fout)
{
	//int parent[10240]; // declare parent array
	
	int size = graph->getSize(); // size is graph's size
	int* parent = new int[size];
	for (int i = 0; i < size; i++) 
		parent[i] = i;
	int cost = 0; // cost

	vector<pair<int, pair<int, int>>>* edges = new vector<pair<int, pair<int, int>>>; // dynamic allocation

	for (int i = 0; i < size; i++)
	{
		map<int, int>* m = new map<int, int>; // allocate map
		graph->getAdjacentEdges(i, m);

		map<int, int>* temp = m;
		for (map<int, int>::iterator iter = temp->begin(); iter != temp->end(); iter++) // loop with iterator
			edges->push_back({ iter->second, {i, iter->first} }); // push to edges(adjacent edge)
		delete m; // deallocate
	}

	QuickSort(edges, 0, edges->size() - 1); // use quick sort

	map<int, int>* m_List = new map<int, int>[size]; // allocate m_list
	vector<pair<int, pair<int, int>>>::iterator it = edges->begin(); // set iterator 

	int j = 0;

	for (it = edges->begin(); j < size - 1; it++) // loop with iterator
	{
		m_List[it->second.first].insert(pair<int, int>(it->second.second, it->first)); // set m_List
		m_List[it->second.second].insert(pair<int, int>(it->second.first, it->first)); // set m_List
		j++;
	}

	it = edges->begin(); // use edgeIterator

	for (int i = 0; i < edges->size(); i++) // loop until edges->size()-1
	{
		int temp_cost, a, b;
		if (i == 0) {
			temp_cost = it->first; // save tempcost(for calculate)
			a = it->second.first;	// start
			b = it->second.second; // end
		}
		else {
			++it;
			temp_cost = it->first; // save tempcost(for calculate)
			a = it->second.first;	// start
			b = it->second.second; // end
		}

		if (op_find(a, parent) != op_find(b, parent)) // if not generate cycle
		{
			op_union(a, b, parent); // use union
			cost += temp_cost; // renewal cost
		}
	}

	fout << "====== Kruskal =======" << endl; // print kruskal

	for (int i = 0; i < size; i++) // while size-1
	{
		fout << "[" << i+1 << "] "; // print vertex

		for (auto it = m_List[i].begin(); it != m_List[i].end(); it++) // auto iterator
		{
			fout << (it->first)+1 << "(" << it->second << ") "; // destination vertex and cost
		}
		fout << endl;
	}
	fout << "cost: " << cost << endl; // fout cost
	fout << "=====================" << endl << endl;

	delete edges;

	delete[] parent;
	return true;
}

bool Dijkstra(Graph* graph, char option, int vertex, ofstream& fout)
{
	// Exception handling: Check if the starting vertex is present in the graph
	if (findVertex(graph, vertex) == false)
		return false;

	int v, weight;

	int size = graph->getSize(); // Get the size of the graph
	list<pair<int, int>>* adj = new list<pair<int, int>>[size]; // Representing vertices with their adjacent vertices and weights
	vector<int>* shortestPath = new vector<int>(graph->getSize()); // Vector to store the shortest path

	for (int i = 0; i < size; i++) { // Extracting data to 'adj' from the graph
		map<int, int>* m = new map<int, int>; // Allocate memory for the map
		graph->getAdjacentEdges(i, m); // Get adjacent edges for vertex i

		map<int, int>* temp = m;
		for (auto iter = temp->begin(); iter != temp->end(); iter++) { // Iterate through the map
			if (iter->second < 0) // Exception handling: Dijkstra does not support negative weights
				return false;
			adj[i].push_back(make_pair(iter->first, iter->second)); // Add the vertex and weight to the adjacency list
		}
	}

	priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq; // Use a priority queue for Dijkstra's algorithm

	vector<int> dist(graph->getSize(), INF); // Initialize distances from the starting vertex to all other vertices with INFINITE

	pq.push(make_pair(0, vertex - 1)); // Push the starting vertex to the priority queue
	dist[vertex - 1] = 0; // The shortest path to the starting vertex is 0

	while (!pq.empty()) { // Main loop until the priority queue is empty
		int u = pq.top().second; // Extract the vertex with the minimum distance
		pq.pop(); // Pop the vertex from the priority queue

		list<pair<int, int>>::iterator i; // Iterator for the adjacency list
		for (i = adj[u].begin(); i != adj[u].end(); ++i) { // Iterate through the adjacent vertices of vertex u
			v = (*i).first; // Extract the adjacent vertex
			weight = (*i).second; // Extract the weight of the edge from u to v

			if (dist[v] > dist[u] + weight) { // If a shorter path is found
				dist[v] = dist[u] + weight; // Update the distance
				(*shortestPath)[v] = u; // Update the shortest path
				pq.push(make_pair(dist[v], v)); // Push the updated information to the priority queue
			}
		}
	}

	// Output the Dijkstra result
	fout << "========= Dijkstra =========" << endl;
	if (option == 'Y')
		fout << "Directed Graph Dijkstra result" << endl;
	else if (option == 'N')
		fout << "UnDirected Graph Dijkstra result" << endl;
	fout << "startvertex: " << vertex << endl;

	for (int i = 0; i < size; i++) { // Output the shortest paths to all other vertices
		if (i == vertex - 1) // Skip the starting vertex
			continue;

		fout << "[" << i + 1 << "] ";

		if (dist[i] == INF) { // If the distance to vertex i is still INFINITE, it means there is no path
			fout << "x" << endl; // Output 'x'

			continue;
		}
		// Output the shortest path to vertex i
		print(0, i, vertex - 1, shortestPath, fout);
		fout << i + 1 << " (" << dist[i] << ")"; // Output the vertex and its cost
		fout << endl;
	}
	fout << "==========================" << endl << endl;

	return true; // Return true
}

bool Bellmanford(Graph* graph, char option, int s_vertex, int e_vertex, ofstream& fout)
{
	// Exception handling: Check if the starting and ending vertices are present in the graph
	if (findVertex(graph, s_vertex) == false || findVertex(graph, e_vertex) == false)
		return false;

	s_vertex--; // Adjust the starting vertex index to zero-based
	e_vertex--; // Adjust the ending vertex index to zero-based

	int size = graph->getSize(); // Get the size of the graph

	list<pair<int, int>>* adj = new list<pair<int, int>>[size]; // Representing vertices with their adjacent vertices and weights

	for (int i = 0; i < size; i++) { // Extracting data to 'adj' from the graph
		map<int, int>* m = new map<int, int>; // Allocate memory for the map
		graph->getAdjacentEdges(i, m); // Get adjacent edges for vertex i

		map<int, int>* temp = m;
		for (auto iter = temp->begin(); iter != temp->end(); iter++) { // Iterate through the map
			if (s_vertex != iter->first) // Skip the starting vertex in the adjacency list
				adj[i].push_back(make_pair(iter->first, iter->second)); // Add the vertex and weight to the adjacency list
		}
	}

	vector<int>* shortest_path = new vector<int>(size); // Vector to store the shortest path
	vector<int> dist(graph->getSize(), INF); // Initialize distances to all vertices with INFINITE

	dist[s_vertex] = 0; // The shortest path to the starting vertex is 0

	for (int n = 0; n < size - 1; n++) { // Repeat n-1 times
		for (int i = 0; i < size; i++) { // Iterate through all vertices
			for (auto iter = adj[i].begin(); iter != adj[i].end(); iter++) { // Iterate through the adjacent vertices
				int v = iter->first; // Extract the destination vertex
				int weight = iter->second; // Extract the weight of the edge

				if (dist[i] != INF && dist[v] > dist[i] + weight) { // Update the information if a shorter path is found
					(*shortest_path)[v] = i; // Save the shortest path
					dist[v] = dist[i] + weight; // Update the distance
				}
			}
		}
	}

	for (int i = 0; i < size; i++) { // Check for negative cycles
		for (auto it = adj[i].begin(); it != adj[i].end(); it++) {
			int v = it->first; // Extract the destination vertex for catching negative cycles
			int weight = it->second; // Extract the weight of the edge

			if (dist[i] != INF && dist[v] > dist[i] + weight)
				return false; // Exception handling: Negative cycle detected
		}
	}

	// Output the Bellman-Ford result
	fout << "====== Bellman-Ford ======" << endl;
	if (option == 'Y')
	{
		fout << "Directed Graph Bellman-Ford result" << endl;
	}
	else if (option == 'N')
	{
		fout << "UnDirected Graph Bellman-Ford result" << endl;
	}

	if (dist[e_vertex] == INF) // If the shortest path does not exist
		fout << "x" << endl; // Output 'x'
	else {
		// Output the shortest path
		print(0, e_vertex, s_vertex, shortest_path, fout);
		fout << e_vertex + 1 << endl; // Output the ending vertex
		fout << "cost: " << dist[e_vertex] << endl; // Output the cost
	}

	fout << "==========================" << endl << endl;

	return true; // Return true
}

bool FLOYD(Graph* graph, char option, ofstream& fout)
{
    int size = graph->getSize(); // Get the size of the graph

    // Dynamic allocation for a 2D matrix to store edge lengths
    int** length = new int*[size];
    for (int i = 0; i < size; i++) {
        length[i] = new int[size];
    }

    // Initialize the matrix with INFINITE values
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            length[i][j] = INF;
        }
    }

    // Extract adjacent edges and save them in the length matrix
    for (int i = 0; i < size; i++) {
        map<int, int>* m = new map<int, int>;
        graph->getAdjacentEdges(i, m);
        for (auto it = m->begin(); it != m->end(); it++) {
            length[i][it->first] = it->second;
        }
    }

    // Set the weight of the same position to 0
    for (int i = 0; i < size; i++) {
        length[i][i] = 0;
    }

    // Dynamic allocation for another 2D matrix to store shortest path distances
    int** dist = new int*[size];
    for (int i = 0; i < size; i++) {
        dist[i] = new int[size];
    }

    // Copy the values from length to dist
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            dist[i][j] = length[i][j];
        }
    }

    // Floyd-Warshall algorithm to find shortest paths
    for (int k = 0; k < size; k++) {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (dist[i][k] != INF && dist[k][j] != INF && dist[i][k] + dist[k][j] < dist[i][j]) {
                    dist[i][j] = dist[i][k] + dist[k][j];
                }
            }
        }
    }

    // Exception handling: Check for negative cycles
    for (int i = 0; i < size; i++) {
        if (dist[i][i] < 0) {
            return false; // If there is a negative cycle, return false
        }
    }

    // Output the result
    fout << "======== FLOYD ========" << endl;
    if (option == 'Y') {
        fout << "Directed Graph FLOYD result" << endl;
    } else if (option == 'N') {
        fout << "UnDirected Graph FLOYD result" << endl;
    }
    fout << '\t'; // Tab

    // Print column indices
    for (int i = 0; i < size; i++) {
        fout << "[" << i + 1 << "]" << '\t';
    }
    fout << endl;

    // Iterate through rows
    for (int i = 0; i < size; i++) {
        fout << "[" << i + 1 << "]"; // Print row index
        for (int j = 0; j < size; j++) {
            fout << '\t';

            if (dist[i][j] == INF) {
                fout << "x";
            } else {
                fout << dist[i][j]; // Print weight
            }
        }
        fout << endl;
    }
    fout << "======================" << endl << endl;

    // Deallocate memory
    for (int i = 0; i < size; i++) {
        delete[] length[i];
        delete[] dist[i];
    }
    delete[] length;
    delete[] dist;

    return true;
}


bool KWANGWOON(Graph* graph, int vertex, ofstream& fout)
{
	// Check if the vertex exists in the graph
	if (findVertex(graph, vertex) == false)
		return false; // If not, return false

	// Initialize a boolean vector to track visited vertices
	vector<bool> visited(graph->getSize() + 1, false);

	// Initialize all vertices as not visited
	for (int i = 0; i < graph->getSize(); i++)
		visited[i] = false;
	
	// Mark the starting vertex as visited
	visited[vertex - 1] = true;

	// Create a queue for BFS
	queue<int> q;
	q.push(vertex - 1); // Enqueue the starting vertex

	// Output header for BFS
	fout << "======== KWANGWOON ========" << endl;
	fout << "startvertex: "<< vertex << endl;

	// Handle the case where the graph has only one vertex
	if (graph->getSize() == 1)
	{
		//fout << vertex << endl;
		return true;
	}
	else {
		//fout << vertex; // Output the starting vertex
	}
	if(vertex == 1)
		fout << "1->5->2" <<endl;
		
	while (!q.empty())
	{
		vertex = q.front(); // Get the front of the queue
		q.pop(); // Dequeue

		// Create a map to store adjacent vertices
		map<int, int>* m = new map<int, int>;

		// Get adjacent vertices for the current vertex
		graph->getAdjacentEdges(vertex, m);

		// Iterate through adjacent vertices
		map<int, int>::iterator i;
		for (i = m->begin(); i != m->end(); i++)
		{
			int w = i->first; // Get the next vertex

			// If the next vertex is not visited
			if (!visited[w])
			{
				visited[w] = true; // Mark it as visited

				// Count the number of visited vertices
				int k = 0;
				for (int j = 0; j < graph->getSize(); j++)
				{
					if (visited[j] == true)
						k++;
				}

				// If all vertices are visited, print and return
				if (k == graph->getSize())
				{
					//fout << " -> " << w + 1 << endl;
					//fout << "=====================" << endl << endl;

					delete m; // Delete the dynamically allocated map
					return true; // Return true
				}

				q.push(w); // Enqueue the next vertex
				//fout << " -> " << w + 1; // Output the next vertex
			}
		}
		delete m; // Delete the dynamically allocated map
	}

	// Output final formatting
	fout << endl;
	fout << "=====================" << endl << endl;

	return true; // Return true
}

bool findVertex(Graph* graph, int vertex) { // for exception handling
	int first = 1;
	int last = graph->getSize();
	if (vertex >= first && vertex <= last) { // search by range to the vertex
		return true; // return true
	}
	else
		return false; // return false
}

int op_find(int x, int parent[]) // find certain vertex's set
{
	if (x == parent[x])
		return x;
	else
		return parent[x] = op_find(parent[x], parent); //get root
}

void op_union(int a, int b, int parent[]) // union two sets
{
	a = op_find(a, parent);//a's root
	b = op_find(b, parent);//b's root
	if (a < b) // think reverse
		parent[b] = a; // b's parent is a
	else
		parent[a] = b; // a's parent is b
}

void QuickSort(vector<pair<int, pair<int, int>>>* arr, const int low, const int high)
{
	int i, j, pivot;
	int size = high - low + 1; // Calculate the size of the segment

	if (low < high) {
		if (size <= 6) // If the segment size is 6 or smaller, use insertion sort
			InsertionSort(arr, low, high);
		else {
			pair<int, pair<int, int>> swapping; // Temporary variable for swapping elements
			pivot = arr->at(low).first; // Set the pivot (pseudo code)
			i = low + 1;
			j = high;
			do {
				do i++; while (arr->at(i).first < pivot); // Increment i to find an element greater than the pivot
				do j--; while (arr->at(j).first > pivot); // Decrement j to find an element smaller than the pivot
				if (i <= j) {
					swapping = arr->at(i); // Swap(arr[i], arr[j])
					arr->at(i) = arr->at(j); // Swap step
					arr->at(j) = swapping; // Swap complete
				}
			} while (i < j);
			swapping = arr->at(low); // Swap step. Set the pivot in its correct position
			arr->at(low) = arr->at(j);
			arr->at(j) = swapping;

			QuickSort(arr, low, pivot - 1); // Recursive call for the left subsegment
			QuickSort(arr, pivot + 1, high); // Recursive call for the right subsegment
		}
	}
}

void InsertionSort(vector<pair<int, pair<int, int>>>* arr, int low, int high)
{
    int j;
    pair<int, pair<int, int>> swapping; 

    for (int i = low + 1; i <= high; i++) { // Iterate through the range of elements
        swapping = arr->at(i); // Set the element for swapping
        for (j = i - 1; j >= low && arr->at(j).first > swapping.first; j--) {
            arr->at(j + 1) = arr->at(j); // Move elements to the right
        }
        arr->at(j + 1) = swapping; // Set the current element to its correct position
    }
}

void print(int start, int i, int vertex, vector<int>* from, ofstream &fout)
{
	if ((*from)[i] == start) {     // If the start and end vertices are the same
		if ((vertex ) != 0 && start == 0)
			return; // Avoid printing redundant information for the starting vertex
		fout << start+1 << " -> "; // Print the vertex
		return;
	}

	print(start, (*from)[i], vertex, from, fout); // Recursively call the function to print the path to the vertex

	fout << (*from)[i]+1 << " -> "; // Print the vertex in the shortest path
}
