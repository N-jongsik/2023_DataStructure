#pragma once
#include "LoanBookData.h"
#include "LoanBookHeapNode.h"

class LoanBookHeap
{
private:
    LoanBookHeapNode* root;

public:
    LoanBookHeap() {
        this->root = NULL;
    };
    ~LoanBookHeap() {

    }

    void setRoot(LoanBookHeapNode* pN) { this->root = pN; }
    LoanBookHeapNode* getRoot() { return root; }

    void heapifyUp(LoanBookHeapNode* pN);
    void heapifyDown(LoanBookHeapNode* pN);

    bool Insert(LoanBookData* data);
    void InsertNode(LoanBookHeapNode* pRoot, LoanBookHeapNode* pNewNode);

    void printLevelOrder(LoanBookHeapNode* root);
    bool containsBook(LoanBookHeapNode* node, const string& bookName);

    void printSortedData(ofstream& flog);
    void traverseHeap(LoanBookHeapNode* node, ofstream& flog);

    void Delete(ofstream& flog);

    LoanBookHeapNode* getLastNode(LoanBookHeapNode* node);
    void removeLastNode(LoanBookHeapNode* node);
};