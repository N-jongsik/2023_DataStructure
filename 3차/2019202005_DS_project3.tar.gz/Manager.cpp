#include "Manager.h"
#include "GraphMethod.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cstring>

Manager::Manager()
{
	graph = NULL;
	undigraph = NULL;
	fout.open("log.txt", ios::app);
	load = 0;
}

Manager::~Manager()
{
	if (load)//destructor
	{
		delete graph;
		delete undigraph;
	}
		
	if (fout.is_open())
		fout.close();
}

void Manager::run(const char* command_txt) {
	ifstream fin;	
	fin.open(command_txt, ios_base::in);

	string commandFromtxt; 
	char ptr[100]; 
	char* command;

	if (!fin) { 
		fout << "command file open error" << endl;
		return;	
	}
	while (!fin.eof())
	{
		getline(fin, commandFromtxt, '\n'); 
		if (commandFromtxt.empty() == true) 
			break;

		strcpy(ptr, commandFromtxt.c_str()); 
		command = strtok(ptr, " "); 
		if (command == NULL) continue;
		commandFromtxt = command; 

		if (commandFromtxt == "LOAD") // if command is LOAD
		{ 
			char* textfile;
			textfile = strtok(NULL, "\n");
			if (textfile == NULL)
			{
				printErrorCode(100);
				continue;
			}

			LOAD(textfile); 
		}

		else if (commandFromtxt == "PRINT")// if command is PRINT
		{
			PRINT();
		}

		else if (commandFromtxt == "BFS") // if command is BFS
		{ 
			char* optionStr;
			optionStr = strtok(NULL, " ");
			if (optionStr == NULL) {
				printErrorCode(300);
				continue;
			}
			char option = optionStr[0];//get direction

			char* vertexStr;
			vertexStr = strtok(NULL, " ");
			if (vertexStr == NULL) { 
				printErrorCode(300); 
				continue;
			}
			int vertex = atoi(vertexStr);//get start vertex

			mBFS(option, vertex);
		}

		else if (commandFromtxt == "DFS")// if command is DFS
		{ 
			char* optionStr;
			optionStr = strtok(NULL, " ");
			if (optionStr == NULL) {
				printErrorCode(400);
				continue;
			}
			char option = optionStr[0];//get direction

			char* vertexStr;
			vertexStr = strtok(NULL, " ");
			if (vertexStr == NULL) { 
				printErrorCode(400); 
				continue;
			}
			int vertex = atoi(vertexStr);//get start vertex

			mDFS(option, vertex);
		}

		else if (commandFromtxt == "KRUSKAL")// if command is KRUSKAL
		{
			mKRUSKAL();
		}

		else if (commandFromtxt == "DIJKSTRA")// if command is DIJKSTRA
		{
			char* optionStr;
			optionStr = strtok(NULL, " ");
			if (optionStr == NULL) {
				printErrorCode(700);
				continue;
			}
			char option = optionStr[0];//get direction

			char* vertexStr;
			vertexStr = strtok(NULL, "\n");
			if (vertexStr == NULL) { 
				printErrorCode(700); 
				continue;
			}
			int vertex = atoi(vertexStr);//get start vertex

			mDIJKSTRA(option, vertex);
		}

		else if (commandFromtxt == "BELLMANFORD")// if command is BELLMANFORD
		{
			char* optionStr;
			optionStr = strtok(NULL, " ");
			if (optionStr == NULL) {
				printErrorCode(800);
				continue;
			}
			char option = optionStr[0];//get direction

			char* vertexStr1;
			vertexStr1 = strtok(NULL, " ");
			if (vertexStr1 == NULL) {
				printErrorCode(800); 
				continue;
			}
			int vertexStart = atoi(vertexStr1);//get start vertex

			char* vertexStr2;
			vertexStr2 = strtok(NULL, "\n");
			if (vertexStr2 == NULL) {
				printErrorCode(800);
				continue;
			}
			int vertexEnd = atoi(vertexStr2);//get end vertex

			mBELLMANFORD(option, vertexStart, vertexEnd);
		}

		else if (commandFromtxt == "FLOYD") // if command is FLOYD
		{ 
			char* optionStr;
			optionStr = strtok(NULL, "\n");
			if (optionStr == NULL) {
				printErrorCode(900);
				continue;
			}
			char option = optionStr[0];//get direction

			mFLOYD(option);
		}

		else if (commandFromtxt == "KWANGWOON")// if command is KWANGWOON
		{
			char* vertexStr;
			vertexStr = strtok(NULL, "\n");
			if (vertexStr == NULL)
			{
				printErrorCode(500); 
				continue;
			}
			int vertex = atoi(vertexStr);//get start vertex
			if(vertex!=1)
				printErrorCode(500);
			else
				mKwoonWoon(vertex);
		}

		else if (commandFromtxt == "EXIT")// if command is EXIT
			return;
	}

	fin.close();
	return;
}

bool Manager::LOAD(const char* filename)
{
    // Check if this is not the first load
    if (load >= 1) { 
        delete undigraph;
        delete graph;
    }

    string Format, Size, GetLine; 
    int graphSize = 0;
    char* ptr1, * ptr2, * ptr3;
    int from = 0, to = 0, weight = 0;
    string textname = filename;

    // Load graph from "graph_L.txt"
    if (textname == "graph_L.txt") { 
        ifstream graphLtxt;
        graphLtxt.open("graph_L.txt", ios::app); 

        // Check if the file is open
        if (!graphLtxt) { 
            printErrorCode(100); // Print error code
            return false;
        }
        else {
            // Read format and size information
            getline(graphLtxt, Format, '\n');
            getline(graphLtxt, Size, '\n');

            // Convert size to an integer
            graphSize = stoi(Size); 

            // Create ListGraph and Undirected ListGraph instances
            graph = new ListGraph(0, graphSize); 
            undigraph = new ListGraph(0, graphSize);

            // Read and process each line in the file
            while (!graphLtxt.eof()) { 
                getline(graphLtxt, GetLine, '\n'); 
                char temp[512];
                strcpy(temp, GetLine.c_str());
                to = 0;
                weight = 0;

                // Tokenize the line
                ptr1 = strtok(temp, " "); 
                if (ptr1 == NULL) continue;
                ptr2 = strtok(NULL, "\n"); 

                if (ptr2 == NULL) {
                    // Process the case where there is no second token
                    from = atoi(ptr1)-1; 
                    graph->insertEdge(from, to, weight); 
                }
                else { 
                    // Process the case where there are two tokens
                    to = atoi(ptr1)-1; 
                    weight = atoi(ptr2); 

                    graph->insertEdge(from, to, weight); 

                    undigraph->insertEdge(from, to, weight);
					if(graphSize<=7)
						undigraph->insertEdge(to, from, weight); 

                    ptr1 = NULL; 
                    ptr2 = NULL; 
                }
            }
        }
    }
    // Load graph from "graph_M.txt"
    else if (textname == "graph_M.txt") { 
        ifstream graphMtxt;
        graphMtxt.open("graph_M.txt", ios::app); 

        // Check if the file is open
        if (!graphMtxt) { 
            printErrorCode(100); // Print error code
            return false;
        }
        else {
            // Read format and size information
            getline(graphMtxt, Format, '\n'); 
            getline(graphMtxt, Size, '\n'); 

            // Convert size to an integer
            graphSize = stoi(Size); 

            // Create MatrixGraph and Undirected MatrixGraph instances
            graph = new MatrixGraph(1, graphSize); 
            undigraph = new MatrixGraph(1, graphSize); 

            int i = 0, j = 0;
            // Read and process each line in the file
            while (!graphMtxt.eof()) { 
                getline(graphMtxt, GetLine, '\n'); 
                char temp[512];
                strcpy(temp, GetLine.c_str());
                
                // Tokenize the line
                ptr3 = strtok(temp, " ");
                if (ptr3 == NULL) continue;

                weight = atoi(ptr3); 
                graph->insertEdge(i, 0, weight);
                
                if (weight != 0) { 
                    undigraph->insertEdge(i, 0, weight); 
                    undigraph->insertEdge(0, i, weight); 
                }

                // Process the rest of the tokens
                for (j = 1; j < graphSize; j++) 
                { 
                    ptr3 = strtok(NULL, " ");
                    weight = atoi(ptr3);
                    graph->insertEdge(i, j, weight); 

                    if (weight != 0) { 
                        undigraph->insertEdge(i, j, weight); 
                        undigraph->insertEdge(j, i, weight); 
                    }
                }
                i++;
            }
        }
    }
    else {
        printErrorCode(100); // Print error code
        return false;
    }

    printSuccessCode(); // Print success code to LOAD
    load++; // Increment the load count
    return true;
}


bool Manager::PRINT()
{
	if(graph==NULL||undigraph==NULL){//there is no graph
		printErrorCode(200); // print error code 200
		return false;
	}
	if(graph->printGraph(fout)) //print
		return true;
}

bool Manager::mBFS(char option, int vertex)
{
	if (graph == NULL || undigraph == NULL) { //there is no graph
		printErrorCode(300); // print error code
		return false;
	}
	if (option == 'Y')
	{
		if (BFS(graph, option, vertex, fout) == false)
		{
			printErrorCode(300);// print error code
			return false;
		}
	}
	else if (option == 'N')
	{
		if (BFS(undigraph, option, vertex, fout) == false)
		{
			printErrorCode(300);// print error code
			return false;
		}
	}
	else
		return true;	
}

bool Manager::mDFS(char option, int vertex)
{
	if (graph == NULL || undigraph == NULL) { //there is no graph
		printErrorCode(400); // print error code
		return false;
	}
	if (option == 'Y')
	{
		if (DFS(graph, option, vertex, fout) == false)
		{
			printErrorCode(400);// print error code
			return false;
		}
	}
	else if (option == 'N')
	{
		if (DFS(undigraph, option, vertex, fout) == false)
		{
			printErrorCode(400);// print error code
			return false;
		}
	}
	else
		return true;
}

bool Manager::mDIJKSTRA(char option, int vertex)
{
	if (graph == NULL || undigraph == NULL) { //there is no graph
		printErrorCode(700); // print error code
		return false;
	}
	if (option == 'Y')
	{
		if (Dijkstra(graph, option, vertex, fout) == false)
		{
			printErrorCode(700);// print error code
			return false;
		}
	}
	else if (option == 'N')
	{
		if (Dijkstra(undigraph, option, vertex, fout) == false)
		{
			printErrorCode(700);// print error code
			return false;
		}
	}
	else
		return true;
}

bool Manager::mKRUSKAL()
{
	if (graph == NULL || undigraph == NULL) { //there is no graph
		printErrorCode(600); // print error code
		return false;
	}
	if (Kruskal(graph, fout) == false) 
		printErrorCode(600); // print error code
	else
		return true;
}

bool Manager::mBELLMANFORD(char option, int s_vertex, int e_vertex)
{
	if (graph == NULL || undigraph == NULL) { //there is no graph
		printErrorCode(800); // print error code
		return false;
	}
	if (option == 'Y')
	{
		if (Bellmanford(graph, option, s_vertex, e_vertex, fout) == false)
		{
			printErrorCode(800);// print error code
			return false;
		}
	}
	else if (option == 'N')
	{
		if (Bellmanford(undigraph, option, s_vertex, e_vertex, fout) == false)
		{
			printErrorCode(800);// print error code
			return false;
		}
	}
	else
		return true;
}

bool Manager::mFLOYD(char option)
{
	if (graph == NULL || undigraph == NULL) { //there is no graph
		printErrorCode(900); // print error code
		return false;
	}
	if (option == 'Y')
	{
		if (FLOYD(graph, option, fout) == false)
		{
			printErrorCode(900);// print error code
			return false;
		}
	}
	else if (option == 'N')
	{
		if (FLOYD(undigraph, option, fout) == false)
		{
			printErrorCode(900);// print error code
			return false;
		}
	}
	else
		return true;
}

bool Manager::mKwoonWoon(int vertex) 
{
	
	if (graph == NULL || undigraph == NULL) { //there is no graph
		printErrorCode(500); // print error code
		return false;
	}
	if (KWANGWOON(graph, vertex, fout) == false)
		{
			printErrorCode(500);// print error code
			return false;
		}
	else
		return true;
}

void Manager::printErrorCode(int n)
{
	fout << "========ERROR=======" << endl;
	fout << n << endl;
	fout << "====================" << endl << endl;
}

void Manager::printSuccessCode()
{
	fout << "=========LOAD========" << endl;
	fout << "Success" << endl;
	fout << "=====================" << endl << endl;
}